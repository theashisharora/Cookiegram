package com.cookiegram.app.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cookiegram.app.beans.Order;
import com.cookiegram.app.repository.OrderRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;

    public Order save(Order order) {
        return orderRepository.save(order);
    }

    public List<Order> getRecentOrders() {
        return orderRepository.findTop10ByOrderByCreatedAtDesc();
    }
    
    public List<Order> findAll() {
        return orderRepository.findAll();
    }
}
