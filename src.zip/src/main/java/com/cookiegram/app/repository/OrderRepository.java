package com.cookiegram.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cookiegram.app.beans.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {

    // For admin dashboard
    List<Order> findTop10ByOrderByCreatedAtDesc();
}
