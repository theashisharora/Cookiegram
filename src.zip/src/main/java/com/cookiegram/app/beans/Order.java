package com.cookiegram.app.beans;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Who is sending the CookieGram
    @NotBlank
    private String senderName;

    @NotBlank
    private String senderEmail;

    // Who is receiving it
    @NotBlank
    private String recipientName;

    @NotBlank
    private String recipientEmail;

    // Simple choice for now (could later be linked to Promotion)
    @NotBlank
    private String cookieType;     // e.g. "Choco Chip", "Red Velvet"

    @NotNull
    @Min(1)
    @Max(24)
    private Integer quantity;

    // Delivery date chosen by customer
    @NotNull
    private LocalDate deliveryDate;

    @Column(length = 1000)
    private String message;

    private LocalDateTime createdAt;

    @PrePersist
    public void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }
}
