package com.cookiegram.app.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.cookiegram.app.services.OrderService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class DashboardController {

    private final OrderService orderService;

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/customer")
    public String customerDashboard() {
        return "customer";
    }

    // @GetMapping("/admin")
   // public String adminDashboard(Model model) {
     //   model.addAttribute("recentOrders", orderService.getRecentOrders());
       // return "admin";
    //}

    @GetMapping("/employee")
    public String employeeDashboard() {
        return "employee";
    }

    @GetMapping("/403")
    public String accessDenied() {
        return "403";
    }
}
